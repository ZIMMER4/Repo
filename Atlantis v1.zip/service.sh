MODDIR=${0%/*}

# This script will be executed in late_start service mode
dbg 'Sleeping until boot completes.'
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 5
done

#hahs
set -o standalone

#Sleep
sleep 30
stop logd
stop tcpdump
stop cnss_diag
stop statsd
stop traced
stop idd-logreader
stop idd-logreadermain
stop vendor.perfservice
stop miuibooster
tweaks
kernel
hoh
unity_sol
unity_2sol
cpu_boostZ

#Sio
chmod 0755 /proc/cpufreq/MT_CPU_DVFS_L
chmod 0755 /proc/MT_CPU_DVFS_LL
chmod 0755 /sys/kernel/eara_thermal
chmod 0755 /sys/kernel/eara_thermal/enable
chmod 0755 /sys/kernel/ged
chmod 0755 /sys/kernel/ged/hal
chmod 0755 /sys/kernel/fpsgo
chmod 0755 /proc/gpufreq/gpufreq_power_limited
chmod 0755 /sys/kernel/fpsgo/common
chmod 0755 /sys/kernel/fpsgo/common/fpsgo_enable
echo '0' > /sys/kernel/fpsgo/common/fpsgo_enable
chmod 0755 /sys/kernel/ged/hal/custom_boost_gpu_freq
chmod 0755 /sys/kernel/fpsgo/common/force_onoff
echo 1 > /sys/kernel/fpsgo/common/force_onoff
chmod 0755 /sys/kernel/ged/gpu_tuner
echo '1' > /sys/kernel/ged/hal/gpu_boost_level
echo '900000' > /sys/kernel/ged/hal/custom_boost_gpu_freq
echo '0' > /sys/kernel/eara_thermal/enable;
chmod 0755 /proc/gpufreq/MT_CPU_DVFS_CCI
echo '1' > /sys/kernel/eara_thermal/fake_throttle;
echo '0' > /sys/kernel/fpsgo/common/gpu_block_boost;
chmod 0755 /proc/gpufreq
chmod 0755 /proc/gpufreq/gpufreq_opp_stress_test
echo '1' > /proc/gpufreq/gpufreq_opp_stress_test
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy4/scaling_governor;
echo 'schedutil' > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor;
chmod 644 /sys/module/workqueue/parameters/power_efficient;
echo '0' > /sys/module/overheat_mitigation/parameters/enable;
echo 'N' > /sys/module/workqueue/parameters/power_efficient;
echo 'N' > /sys/module/msm_thermal/parameters/enabled;
echo '0' > /sys/module/msm_thermal/core_control/cpus_offlined;
echo '0' > /sys/module/msm_thermal/core_control/enabled;
echo 'manual' > /sys/devices/system/cpu/power/control
echo 'N' > /sys/module/msm_thermal/parameters/enabled;
echo '0' > /sys/module/msm_thermal/core_control/cpus_offlined
echo '0' > /sys/module/msm_thermal/core_control/enabled;
echo '2' > /sys/class/devfreq/5000000.qcom,kgsl-3d0/adrenoboost;
echo '0' > /sys/class/kgsl/kgsl-3d0/throttling;
echo '2' > /sys/class/devfreq/5900000.qcom,kgsl-3d0/subsystem/5900000.qcom,kgsl-3d0/adrenoboost;
echo '0' > /sys/module/adreno_idler/parameters/adreno_idler_active; 
echo '8' > /sys/module/lazyplug/parameters/nr_possible_cores ;
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/uevent;
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms;
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms;
echo '0' > /sys/module/overheat_mitigation/parameters/enable;
chmod 0755 /sys/devices/system/cpu/sched/sched_boost;
chmod 0755 /sys/devices/system/cpu/sched
echo '1' > /sys/devices/system/cpu/perf/enable;
echo 'boost' > /sys/devices/system/cpu/sched/sched_boost;
echo '3' > /proc/cpufreq/cpufreq_power_mode;
echo '1' > /proc/cpufreq/cpufreq_imax_enable;
echo '0' > /proc/cpufreq/cpufreq_imax_thermal_protect;
echo '1' > /sys/module/ged/parameters/gx_game_mode;
echo '1' /sys/module/ged/parameters/gx_3D_benchmark_on;
echo '1' > /sys/module/ged/parameters/cpu_boost_policy;
echo '1024' > /proc/sys/kernel/random/read_wakeup_threshold
echo '1024' > /proc/sys/kernel/random/write_wakeup_threshold
echo '1' >  /sys/module/ged/parameters/boost_extra;
echo '20000000' > /sys/module/ged/parameters/target_t_cpu_remained;
echo "0" > /sys/devices/system/cpu/cpufreq/schedutil/iowait_boost_enable
echo '1' > /sys/module/ged/parameters/enable_gpu_boost;
echo '1' > /sys/module/ged/parameters/ged_boost_enable;
echo '1' > /sys/module/ged/parameters/gx_boost_on;
echo '1' > /sys/module/ged/parameters/ged_smart_boost;
echo '5' > /dev/stune/top-app/schedtune.boost;
echo '0' > /dev/stune/foreground/schedtune.prefer_idle;
echo '0' >  /dev/stune/foreground/schedtune.boost;
echo '40' > /dev/stune/rt/schedtune.boost;
echo '1' > /dev/stune/nnapi-hal/schedtune.boost;
echo '0' > /sys/devices/system/cpu/offline
chmod 0644 /sys/module/hid_magicmouse/parameters/scroll_speed
chmod 0755 /system/bin/cleaner
chmod 0777 /system/bin
echo '100' > /sys/module/hid_magicmouse/parameters/scroll_speed 
chmod 0444 /sys/module/hid_magicmouse/parameters/scroll_speed 
echo 'Y' > /sys/module/hid_magicmouse/parameters/scroll_acceleration
echo '0' > /dev/cpuset/restricted/cpus;
echo '0' > /sys/kernel/oppo_display/cabc
echo '0' > /sys/kernel/oppo_display/LCM_CABC
echo '1' > /proc/touchpanel/oppo_tp_direction
echo '0' > /proc/touchpanel/oppo_tp_limit_enable
echo '1' > /proc/touchpanel/oplus_tp_direction
echo '0' > /proc/touchpanel/oplus_tp_limit_enable
echo '1' > /proc/touchpanel/game_switch_enable
echo '3' > /proc/sys/net/ipv4/tcp_fastopen;
echo '1' > /proc/sys/net/ipv4/tcp_ecn;
echo '0' > /proc/sys/net/ipv4/tcp_syncookies;
echo 'mem' > /sys/power/autosleep;
echo 'deep' > /sys/power/mem_sleep;
chmod 0755 /proc/sys/net/ipv4/
chmod 0755 /proc/sys/net/ipv4/tcp_congestion_control
chmod 0755 /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_fin_wait
chmod 0755 /proc/sys/net/core
chmod 0755 /proc/sys/net/core/default_qdisc
write 'fq_codel' > /proc/sys/net/core/default_qdisc
chmod 0755 /proc/sys/net/netfilter/
echo 'cubic' > /proc/sys/net/ipv4/tcp_congestion_control;
echo '1' > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_fin_wait

#PPM (Mediatek)
echo 1 > /proc/ppm/enabled
echo 0 0 > /proc/ppm/policy_status
echo 1 1 > /proc/ppm/policy_status
echo 2 0 > /proc/ppm/policy_status
echo 3 0 > /proc/ppm/policy_status
echo 4 0 > /proc/ppm/policy_status
echo 5 0 > /proc/ppm/policy_status
echo 6 1 > /proc/ppm/policy_status
echo 7 0 > /proc/ppm/policy_status
echo 8 0 > /proc/ppm/policy_status
echo 9 0 > /proc/ppm/policy_status
cat /proc/ppm/policy_status

#Aol
echo 1 > /proc/gpufreq/gpufreq_power_limited
echo 1 > /proc/gpufreq/gpufreq_power_limited
echo 1 > /proc/gpufreq/gpufreq_power_limited
echo 1 > /proc/gpufreq/gpufreq_power_limited
cat /proc/gpufreq/gpufreq_power_limited

#PowerHal
echo -e 'com.mobile.legends\ncom.tencent.ig\ncom.miHoYo.GenshinImpact\ncom.tencent.tmgp.pubgmhd\ncom.dts.freefireth\ncom.dts.freefiremax\njp.konami.pesam\ncom.pubg.newstate\ncom.garena.game.codm\ncom.pubg.imobile\ncom.ea.gp.apexlegendsmobilefps\ncom.riotgames.league.wildrift\ncom.tencent.tmgp.sgame\ncom.tencent.iglite\ncom.vng.pubgmobile\ncom.miHoYo.bh3oversea\ncom.pubg.krmobile\ncom.rekoo.pubgm\ncom.activision.callofduty.shooter\ncom.je.supersus\ncom.levelinfinite.hotta.gp\ncom.ea.gp.fifamobile\ncom.pwrd.hotta.laohu\ncom.Shooter.ModernWarships\ncom.linecorp.LGGRTHN\ncom.wemade.mir4global\ncom.netease.mrzhna\ncom.carxtech.carxdr2\ncom.pou.zakeh\ncom.garena.game.kgid\ncom.gameloft.android.SAMS.GloftA9SS\ncom.kurogame.gplay.punishing.grayraven.en\ncom.mcpe.minecraftpe.pocket.edition.mcpeminecraftpocketedition\ncom.pearlabyss.blackdesertm.gl\ncom.firsttouchgames.dls7\nskynet.cputhrottlingtest \n' > /data/vendor/powerhal/smarttlingtest \n' > /data/vendor/powerhal/smart

#Applying TCP/IP Parameters at System Boot
echo '256960' > /proc/sys/net/core/optmem_max
echo '256960' > /proc/sys/net/core/rmem_default
echo '256960' > /proc/sys/net/core/rmem_max 
echo '256960' >/proc/sys/net/core/wmem_default 
echo '256960' > /proc/sys/net/core/wmem_max
echo '0' > /proc/sys/net/ipv4/tcp_timestamps
echo '0' > /proc/sys/net/ipv4/tcp_sack
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling

#Speed Ram
echo '1024' > /sys/devices/virtual/block/zram0/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram13/queue/read_ahead_kb
echo '512' > /sys/block/ram0/queue/read_ahead_kb
echo '512' > /sys/block/ram1/queue/read_ahead_kb
echo '512' > /sys/block/ram2/queue/read_ahead_kb
echo '512' > /sys/block/ram3/queue/read_ahead_kb
echo '512' > /sys/block/ram4/queue/read_ahead_kb
echo '512' > /sys/block/ram5/queue/read_ahead_kb
echo '512' > /sys/block/ram6/queue/read_ahead_kb
echo '512' > /sys/block/ram7/queue/read_ahead_kb
echo '512' > /sys/block/ram8/queue/read_ahead_kb
echo '512' > /sys/block/ram9/queue/read_ahead_kb
echo '512' > /sys/block/ram10/queue/read_ahead_kb
echo '512' > /sys/block/ram11/queue/read_ahead_kb
echo '512' > /sys/block/ram12/queue/read_ahead_kb
echo '512' > /sys/block/ram13/queue/read_ahead_kb
echo '512' > /sys/block/ram14/queue/read_ahead_kb
echo '512' > /sys/block/ram15/queue/read_ahead_kb
echo '512' > /sys/block/vnswap0/queue/read_ahead_kb
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo '512' > /sys/devices/virtual/block/ram0/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram0/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram1/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram1/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram2/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram2/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram3/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram3/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram4/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram4/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram5/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram5/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram6/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram6/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram7/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram7/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram8/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram8/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram9/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram9/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram10/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram10/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram11/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram11/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram12/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram12/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram13/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram13/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/zram0/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/zram0/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/bdi/1:0/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:1/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:2/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:3/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:4/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:5/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:6/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:7/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:8/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:9/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:10/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:11/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:12/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/1:13/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:0/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:8/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:16/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:24/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:32/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:40/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:48/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/7:56/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/179:0/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/179:32/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/179:64/read_ahead_kb
echo '512' > /sys/devices/virtual/bdi/253:0/read_ahead_kb

#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 

# Google Service Config Reduce Drain
sleep 0.001
pm enable com.google.android.gms
sleep 0.001
pm enable com.google.android.gsf
sleep 0.001
pm enable com.google.android.gms/.update.SystemUpdateActivity
sleep 0.001
pm enable com.google.android.gms/.update.SystemUpdateService
sleep 0.001
pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver
sleep 0.001
pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver
sleep 0.001
pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver
sleep 0.001
pm enable com.google.android.gsf/.update.SystemUpdateActivity
sleep 0.001
pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity
sleep 0.001
pm enable com.google.android.gsf/.update.SystemUpdateService
sleep 0.001
pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver
sleep 0.001
pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
pm disable com.google.android.gms/NearbyMessagesService
pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver
pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver

# Silence /vendor/build.prop log tag
resetprop persist.sys.scrollingcache 2
resetprop ro.vendor.perf.scroll_opt true
resetprop -n persist.log.tag.RILMUXD S
resetprop -n persist.log.tag.AT S
resetprop -n persist.log.tag.RILC-MTK S
resetprop -n persist.log.tag.RILC S
resetprop -n persist.log.tag.RfxMainThread S
resetprop -n persist.log.tag.RfxRoot S
resetprop -n persist.log.tag.RfxRilAdapter S
resetprop -n persist.log.tag.RfxController S
resetprop -n persist.log.tag.RILC-RP S
resetprop -n persist.log.tag.RfxTransUtils S
resetprop -n persist.log.tag.RfxMclDisThread S
resetprop -n persist.log.tag.RfxCloneMgr S
resetprop -n persist.log.tag.RfxHandlerMgr S
resetprop -n persist.log.tag.RfxIdToStr S
resetprop -n persist.log.tag.RfxDisThread S
resetprop -n persist.log.tag.RfxMclStatusMgr S
resetprop -n persist.log.tag.RIL-Fusion S
resetprop -n persist.log.tag.RtcEccNumberController S
resetprop -n persist.log.tag.RmcEccNumberUrcHandler S
resetprop -n persist.log.tag.RpPhoneNumberController S
resetprop -n persist.log.tag.RilOpProxy S
resetprop -n persist.log.tag.RILC-OP S
resetprop -n persist.log.tag.RilOemClient S
resetprop -n persist.log.tag.WpfaCcciDataHeaderEncoder S
resetprop -n persist.log.tag.WpfaCcciReader S
resetprop -n persist.log.tag.WpfaCcciSender S
resetprop -n persist.log.tag.WpfaControlMsgHandler S
resetprop -n persist.log.tag.WpfaDriver S
resetprop -n persist.log.tag.WpfaDriverAccept S
resetprop -n persist.log.tag.WpfaDriverAdapter S
resetprop -n persist.log.tag.WpfaDriverDeReg S
resetprop -n persist.log.tag.WpfaDriverMessage S
resetprop -n persist.log.tag.WpfaDriverRegFilter S
resetprop -n persist.log.tag.WpfaDriverULIpPkt S
resetprop -n persist.log.tag.WpfaDriverUtilis S
resetprop -n persist.log.tag.WpfaDriverVersion S
resetprop -n persist.log.tag.WpfaFilterRuleReqHandler S
resetprop -n persist.log.tag.WpfaRingBuffer S
resetprop -n persist.log.tag.WpfaShmAccessController S
resetprop -n persist.log.tag.WpfaShmReadMsgHandler S
resetprop -n persist.log.tag.WpfaShmSynchronizer S
resetprop -n persist.log.tag.WpfaShmWriteMsgHandler S
resetprop -n persist.log.tag.wpfa_iptable_android S
resetprop -n persist.log.tag.WpfaRuleRegister S
resetprop -n persist.log.tag.WpfaParsing S
resetprop -n persist.log.tag.WpfaRuleContainer S
resetprop -n persist.log.tag.MtkDct S
resetprop -n persist.log.tag.MtkDc S
resetprop -n persist.log.tag.MtkDcc S
resetprop -n persist.log.tag.MtkRetryManager S
resetprop -n persist.log.tag.DcFcMgr S
resetprop -n persist.log.tag.RtcDC S
resetprop -n persist.log.tag.RmcDcCommon S
resetprop -n persist.log.tag.NetAgentService S
resetprop -n persist.log.tag.NetAgent_IO S
resetprop -n persist.log.tag.NetLnkEventHdlr S
resetprop -n persist.log.tag.RIL-DATA S
resetprop -n persist.log.tag.C2K_RIL-DATA S
resetprop -n persist.log.tag.GsmCdmaPhone S
resetprop -n persist.log.tag.RILMD2-SS S
resetprop -n persist.log.tag.CapaSwitch S
resetprop -n persist.log.tag.DSSelector S
resetprop -n persist.log.tag.DSSelectorOm S
resetprop -n persist.log.tag.DSSelectorOP01 S
resetprop -n persist.log.tag.DSSelectorOP02 S
resetprop -n persist.log.tag.DSSelectorOP09 S
resetprop -n persist.log.tag.DSSelectorOP18 S
resetprop -n persist.log.tag.DSSelectorUtil S
resetprop -n persist.log.tag.SimSwitchOP01 S
resetprop -n persist.log.tag.SimSwitchOP02 S
resetprop -n persist.log.tag.SimSwitchOP18 S
resetprop -n persist.log.tag.IccProvider S
resetprop -n persist.log.tag.IccPhoneBookIM S
resetprop -n persist.log.tag.AdnRecordCache S
resetprop -n persist.log.tag.AdnRecordLoader S
resetprop -n persist.log.tag.AdnRecord S
resetprop -n persist.log.tag.RIL-PHB S
resetprop -n persist.log.tag.MtkIccProvider S
resetprop -n persist.log.tag.MtkIccPHBIM S
resetprop -n persist.log.tag.MtkAdnRecord S
resetprop -n persist.log.tag.MtkRecordLoader S
resetprop -n persist.log.tag.RpPhbController S
resetprop -n persist.log.tag.RmcPhbReq S
resetprop -n persist.log.tag.RmcPhbUrc S
resetprop -n persist.log.tag.RtcPhb S
resetprop -n persist.log.tag.VT S
resetprop -n persist.log.tag.ImsVTProvider S
resetprop -n persist.log.tag.IccCardProxy S
resetprop -n persist.log.tag.IsimFileHandler S
resetprop -n persist.log.tag.IsimRecords S
resetprop -n persist.log.tag.SIMRecords S
resetprop -n persist.log.tag.SpnOverride S
resetprop -n persist.log.tag.UiccCard S
resetprop -n persist.log.tag.UiccController S
resetprop -n persist.log.tag.RIL-SIM S
resetprop -n persist.log.tag.CountryDetector S
resetprop -n persist.log.tag.NetworkStats S
resetprop -n persist.log.tag.NetworkPolicy S
resetprop -n persist.log.tag.DataDispatcher S
resetprop -n persist.log.tag.ImsService S
resetprop -n persist.log.tag.IMS_RILA S
resetprop -n persist.log.tag.IMSRILRequest S
resetprop -n persist.log.tag.ImsManager S
resetprop -n persist.log.tag.ImsApp S
resetprop -n persist.log.tag.ImsBaseCommands S
resetprop -n persist.log.tag.MtkImsManager S
resetprop -n persist.log.tag.MtkImsService S
resetprop -n persist.log.tag.RP_IMS S
resetprop -n persist.log.tag.RtcIms S
resetprop -n persist.log.tag.RtcImsConference S
resetprop -n persist.log.tag.RtcImsDialog S
resetprop -n persist.log.tag.RmcImsCtlUrcHdl S
resetprop -n persist.log.tag.RmcImsCtlReqHdl S
resetprop -n persist.log.tag.ImsCall S
resetprop -n persist.log.tag.ImsPhone S
resetprop -n persist.log.tag.ImsPhoneCall S
resetprop -n persist.log.tag.ImsPhoneBase S
resetprop -n persist.log.tag.ImsCallSession S
resetprop -n persist.log.tag.ImsCallProfile S
resetprop -n persist.log.tag.ImsEcbm S
resetprop -n persist.log.tag.ImsEcbmProxy S
resetprop -n persist.log.tag.OperatorUtils S
resetprop -n persist.log.tag.WfoApp S
resetprop -n persist.log.tag.GsmCdmaConn S
resetprop -n persist.log.tag.Phone S
resetprop -n persist.log.tag.RIL-CC S
resetprop -n persist.log.tag.RpCallControl S
resetprop -n persist.log.tag.RpAudioControl S
resetprop -n persist.log.tag.GsmCallTkrHlpr S
resetprop -n persist.log.tag.MtkPhoneNotifr S
resetprop -n persist.log.tag.MtkFactory S
resetprop -n persist.log.tag.MtkGsmCdmaConn S
resetprop -n persist.log.tag.RadioManager S
resetprop -n persist.log.tag.RIL_Mux S
resetprop -n persist.log.tag.RIL-OEM S
resetprop -n persist.log.tag.RIL S
resetprop -n persist.log.tag.RIL_UIM_SOCKET S
resetprop -n persist.log.tag.RILD S
resetprop -n persist.log.tag.RIL-RP S
resetprop -n persist.log.tag.RfxMessage S
resetprop -n persist.log.tag.RfxDebugInfo S
resetprop -n persist.log.tag.RfxTimer S
resetprop -n persist.log.tag.RfxObject S
resetprop -n persist.log.tag.SlotQueueEntry S
resetprop -n persist.log.tag.RfxAction S
resetprop -n persist.log.tag.RFX S
resetprop -n persist.log.tag.RpRadioMessage S
resetprop -n persist.log.tag.RpModemMessage S
resetprop -n persist.log.tag.PhoneFactory S
resetprop -n persist.log.tag.ProxyController S
resetprop -n persist.log.tag.AirplaneHandler S
resetprop -n persist.log.tag.RfxDefDestUtils S
resetprop -n persist.log.tag.RfxSM S
resetprop -n persist.log.tag.RfxSocketSM S
resetprop -n persist.log.tag.RfxDT S
resetprop -n persist.log.tag.RpCdmaOemCtrl S
resetprop -n persist.log.tag.RpRadioCtrl S
resetprop -n persist.log.tag.RpMDCtrl S
resetprop -n persist.log.tag.RpCdmaRadioCtrl S
resetprop -n persist.log.tag.RpFOUtils S
resetprop -n persist.log.tag.ExternalSimMgr S
resetprop -n persist.log.tag.VsimAdaptor S
resetprop -n persist.log.tag.MtkCsimFH S
resetprop -n persist.log.tag.MtkIsimFH S
resetprop -n persist.log.tag.MtkRuimFH S
resetprop -n persist.log.tag.MtkSIMFH S
resetprop -n persist.log.tag.MtkSIMRecords S
resetprop -n persist.log.tag.MtkSmsCbHeader S
resetprop -n persist.log.tag.MtkSmsManager S
resetprop -n persist.log.tag.MtkSmsMessage S
resetprop -n persist.log.tag.MtkSpnOverride S
resetprop -n persist.log.tag.MtkIccCardProxy S
resetprop -n persist.log.tag.MtkUiccCard S
resetprop -n persist.log.tag.MtkUiccCardApp S
resetprop -n persist.log.tag.MtkUiccCtrl S
resetprop -n persist.log.tag.MtkUsimFH S
resetprop -n persist.log.tag.RpRilClientCtrl S
resetprop -n persist.log.tag.RilMalClient S
resetprop -n persist.log.tag.RpSimController S
resetprop -n persist.log.tag.MtkSubCtrl S
resetprop -n persist.log.tag.RmcEmbmsReq S
resetprop -n persist.log.tag.RmcEmbmsUrc S
resetprop -n persist.log.tag.RtcEmbmsUtil S
resetprop -n persist.log.tag.RtcEmbmsAt S
resetprop -n persist.log.tag.MtkEmbmsAdaptor S
resetprop -n persist.log.tag.RP_DAC S
resetprop -n persist.log.tag.RP_DC S
resetprop -n persist.log.tag.RTC_DAC S
resetprop -n persist.log.tag.RilClient S
resetprop -n persist.log.tag.RmcCommSimReq S
resetprop -n persist.log.tag.RmcCdmaSimRequest S
resetprop -n persist.log.tag.RmcGsmSimRequest S
resetprop -n persist.log.tag.RmcCommSimUrc S
resetprop -n persist.log.tag.RmcGsmSimUrc S
resetprop -n persist.log.tag.RtcCommSimCtrl S
resetprop -n persist.log.tag.RmcCommSimOpReq S
resetprop -n persist.log.tag.RtcRadioCont S
resetprop -n persist.log.tag.RmcDcPdnManager S
resetprop -n persist.log.tag.RmcDcReqHandler S
resetprop -n persist.log.tag.RmcDcUtility S
resetprop -n persist.log.tag.RfxIdToMsgId S
resetprop -n persist.log.tag.RfxOpUtils S
resetprop -n persist.log.tag.RfxMclMessenger S
resetprop -n persist.log.tag.RfxFragEnc S
resetprop -n persist.log.tag.RfxStatusMgr S
resetprop -n persist.log.tag.MTKSST S
resetprop -n persist.log.tag.RfxRilUtils S
resetprop -n persist.log.tag.RmcNwHdlr S
resetprop -n persist.log.tag.RmcNwReqHdlr S
resetprop -n persist.log.tag.RmcNwRTReqHdlr S
resetprop -n persist.log.tag.RmcRatSwHdlr S
resetprop -n persist.log.tag.RtcRatSwCtrl S
resetprop -n persist.log.tag.RtcNwCtrl S
resetprop -n persist.log.tag.RmcRadioReq S
resetprop -n persist.log.tag.RmcCapa S
resetprop -n persist.log.tag.RtcCapa S
resetprop -n persist.log.tag.RpMalController S
resetprop -n persist.log.tag.WORLDMODE S
resetprop -n persist.log.tag.RtcWp S
resetprop -n persist.log.tag.RmcWp S
resetprop -n persist.log.tag.RmcOpRadioReq S
resetprop -n persist.log.tag.RfxContFactory S
resetprop -n persist.log.tag.RfxChannelMgr S
resetprop -n persist.log.tag.RmcCdmaSimUrc S
resetprop -n persist.log.tag.MtkPhoneNumberUtils S
resetprop -n persist.log.tag.RmcOemHandler S
resetprop -n persist.log.tag.RtcModeCont S
resetprop -n persist.log.tag.MtkPhoneSwitcher S
resetprop -n persist.log.tag.RIL-Parcel S
resetprop -n persist.log.tag.RIL-Socket S
resetprop -n persist.log.tag.RIL-SocListen S
resetprop -n persist.log.tag.RIL-Netlink S
resetprop -n persist.log.tag.MwiRIL S
resetprop -n persist.log.tag.PQ_DS S
resetprop -n persist.log.tag.CarrierExpressServiceImpl S
resetprop -n persist.log.tag.CarrierExpressServiceImplExt S
resetprop -n persist.log.tag.PhoneConfigurationSettings S
resetprop -n persist.log.tag.libPowerHal S
resetprop -n persist.log.tag.mtkpower@impl S
resetprop -n persist.log.tag.mtkpower_client S
resetprop -n persist.log.tag.UxUtility S
resetprop -n persist.log.tag.PowerHalAddressUitls S
resetprop -n persist.log.tag.PowerHalMgrImpl S
resetprop -n persist.log.tag.PowerHalMgrServiceImpl S
resetprop -n persist.log.tag.PowerHalWifiMonitor S
resetprop -n ro.vendor.mtk_log_hide_gps 1

# VIRTUAL MEMORY
echo '0' > /sys/module/kernel/parameters/panic
echo '0' > /proc/sys/kernel/panic_on_oops
echo '0' > /sys/module/kernel/parameters/panic_on_warn
echo '0' > /sys/module/kernel/parameters/pause_on_oops
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '0' > /proc/sys/vm/page-cluster
echo '8' > /sys/block/zram0/max_comp_streams 
echo '1' > /sys/module/zswap/parameters/enabled
echo '1' > /proc/sys/net/ipv4/tcp_low_latency
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /proc/sys/vm/page-cluster
echo 'Y' > /proc/sys/vm/swap_ratio_enable
echo '100' > /proc/sys/vm/swappiness
echo '100' > /proc/sys/vm/overcommit_ratio
echo '100' > /proc/sys/vm/dirty_background_ratio;
echo '100' > /proc/sys/vm/dirty_ratio;
echo '200' > /proc/sys/vm/vfs_cache_pressure;
echo '6000' > /proc/sys/vm/dirty_writeback_centisecs;
echo '6000' > /proc/sys/vm/dirty_expire_centisecs;
echo '27337' > /proc/sys/vm/extra_free_kbytes
echo '6422' > /proc/sys/vm/min_free_kbytes;
echo '0' > /proc/sys/vm/oom_kill_allocating_task;
echo '0' > /sys/kernel/ccci/debug;

# Enable UFS power saving after boot
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

#1
while [[ '$(cat /sys/fs/f2fs/*/cp_interval)' != '200' ]]; do
  echo 200 > /sys/fs/f2fs/*/cp_interval
  sleep 1
done

#2
while [[ '$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)' != '50' ]]; do
  echo 50 > /sys/fs/f2fs/*/gc_urgent_sleep_time
  sleep 1
done

#3
while [[ '$(cat /sys/fs/f2fs/*/iostat_enable)' != '1' ]]; do
  echo 1 > /sys/fs/f2fs/*/iostat_enable
  sleep 1
done

#4
while [[ '$(cat /sys/block/sda/queue/discard_max_bytes)' != '134217728' ]]; do
  echo 134217728 > /sys/block/sda/queue/discard_max_bytes
  sleep 1
done

#5
if [[ '$(cat /sys/fs/f2fs/*/gc_urgent_sleep_time)' = '50' ]]; then
  chmod 0444 /sys/fs/f2fs/*/gc_urgent_sleep_time
fi

#affh iyh
cmd settings put secure long_press_timeout 200
cmd settings put secure multi_press_timeout 150
settings put global block_untrusted_touches 0
service call SurfaceFlinger 1008 i32 6

# ngooookkkk
for kernel in /sys/kernel; do
    write $kernel/debug/debug_enabled N
    write $kernel/debug/sched_debug N
    write $kernel/tracing/tracing_on 0
done

# cabd
chmod 0755 /sys/devices/system/cpu/cpu7/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu6/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu5/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu4/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu3/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu2/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu1/hotplug/target
chmod 0755 /sys/devices/system/cpu/cpu0/hotplug/target
chmod 0755 /sys/devices/system/cpu/rq-stats/hotplug_disable
echo '0' > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo '0' > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
echo '1' > /proc/sys/kernel/timer_migration
echo '1' > /sys/devices/system/cpu/rq-stats/hotplug_disable
echo '0' > /sys/devices/system/cpu/cpu7/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu6/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu5/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu4/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu3/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu2/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu1/hotplug/target
echo '0' > /sys/devices/system/cpu/cpu0/hotplug/target

# nyole
echo '1'  > /sys/module/msm_performance/parameters/touchboost
echo '1' > /sys/power/pnpmgr/touch_boost

#sRGB
sleep 30
echo '1' > /sys/module/mdss_fb/parameters/srgb_enabled
echo '1' > /sys/class/graphics/fb0/msm_fb_srgb
done
