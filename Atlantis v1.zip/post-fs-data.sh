MODDIR=${0%/*}

#hhh
set -o standalone

#FSTRIM
fstrim -v /data
fstrim -v /system
fstrim -v /cache
fstrim -v /vendor
fstrim -v /product

# Disable UFS power saving during boot
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/clkgate_enable
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/clkscale_enable
echo '0' > /sys/devices/platform/soc/1d84000.ufshc/hibern8_on_idle_enable

